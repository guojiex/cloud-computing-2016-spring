package com.cloudcomputing.samza.pitt_cabs;

import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.util.HashMap;

import org.apache.samza.config.Config;
import org.apache.samza.storage.kv.KeyValueIterator;
import org.apache.samza.storage.kv.KeyValueStore;
import org.apache.samza.system.IncomingMessageEnvelope;
import org.apache.samza.system.OutgoingMessageEnvelope;
import org.apache.samza.task.InitableTask;
import org.apache.samza.task.MessageCollector;
import org.apache.samza.task.StreamTask;
import org.apache.samza.task.TaskContext;
import org.apache.samza.task.TaskCoordinator;
import org.apache.samza.task.WindowableTask;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

import com.cloudcomputing.samza.pitt_cabs.model.ClientInformation;
import com.cloudcomputing.samza.pitt_cabs.model.DriverInformation;
import com.cloudcomputing.samza.pitt_cabs.model.DriverLocation;
import com.cloudcomputing.samza.pitt_cabs.model.EventClass;
import com.cloudcomputing.samza.pitt_cabs.model.MatchResult;

/**
 * Consumes the stream of driver location updates and rider cab requests.
 * Outputs a stream which joins these 2 streams and gives a stream of rider to
 * driver matches.
 */
public class DriverMatchTask implements StreamTask, InitableTask, WindowableTask {

    /* Define per task state here. (kv stores etc) */
    private KeyValueStore<String, Map<String, Object>> driverLocations;
    private KeyValueStore<String, Map<String, Object>> driversInformation;

    @Override
    @SuppressWarnings("unchecked")
    public void init(Config config, TaskContext context) throws Exception {
        // Initialize stuff (maybe the kv stores?)
        driverLocations = (KeyValueStore<String, Map<String, Object>>) context.getStore("driver-loc");
        driversInformation = (KeyValueStore<String, Map<String, Object>>) context.getStore("driver-list");
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public void process(IncomingMessageEnvelope envelope, MessageCollector collector, TaskCoordinator coordinator) {
        // The main part of your code. Remember that all the messages for a
        // particular partition
        // come here (somewhat like MapReduce). So for task 1 messages for a
        // blockId will arrive
        // at one task only, thereby enabling you to do stateful stream
        // processing.
        String incomingStream = envelope.getSystemStreamPartition().getStream();
        if (incomingStream.equals(DriverMatchConfig.DRIVER_LOC_STREAM.getStream())) {
            this.processDriverLocationEvent((Map<String, Object>) envelope.getMessage());
        } else if (incomingStream.equals(DriverMatchConfig.EVENT_STREAM.getStream())) {
            this.processEventEvent((Map<String, Object>) envelope.getMessage(), collector);
        } else {
            throw new IllegalStateException("Unexpected input stream: " + envelope.getSystemStreamPartition());
        }
    }

    private void processEventEvent(Map<String, Object> map, MessageCollector collector) {

        EventClass value = new EventClass(map);
        switch (value.status) {
        case "LEAVING_BLOCK":
            this.driverLocations.delete(String.valueOf(value.driverId));
            this.driversInformation.delete(String.valueOf(value.driverId));
            break;
        case "ENTERING_BLOCK":
            DriverLocation newLocation = new DriverLocation(value.blockId, value.driverId, "DRIVER_LOCATION",
                    value.latitude, value.longitude);
            this.driverLocations.put(String.valueOf(value.driverId), newLocation.toMap());
            DriverInformation newDriver = new DriverInformation(value.blockId, value.driverId, value.status,
                    value.gender, value.rating, value.salary);
            this.driversInformation.put(String.valueOf(value.driverId), newDriver.toMap());
            break;
        case "RIDE_REQUEST":
            ClientInformation client = new ClientInformation(value.blockId, value.clientId, value.latitude,
                    value.longitude, value.gender_preference);
            MatchResult result = new MatchResult(client.clientId, findAMatchForUser(client));
            Map<String, Object> messageMap = new HashMap<>();
            messageMap.put("clientId", result.clientId);
            messageMap.put("driverId", result.driverId);
            collector.send(new OutgoingMessageEnvelope(DriverMatchConfig.MATCH_STREAM,null,null, messageMap));
            break;
        case "RIDE_COMPLETE":
            this.driversInformation.get(String.valueOf(value.driverId)).put("status", "AVAILABLE");
            this.driverLocations.put(String.valueOf(value.driverId), new DriverLocation(value.blockId, value.driverId,
                    "DRIVER_LOCATION", value.latitude, value.longitude).toMap());
            break;
        default:
            break;
        }

    }

    private static final int MAX_DIST = 5000;

    private double getClientDriverDistance(DriverLocation driver, ClientInformation client) {
        return Math.sqrt(
                Math.pow(2, driver.longitude - client.longitude) + Math.pow(2, driver.latitude - client.latitude));
    }

    private int findAMatchForUser(ClientInformation client) {
        KeyValueIterator<String, Map<String, Object>> drivers = driversInformation.all();
        double highest = Double.MIN_NORMAL;
        int driverIdWithHighestScore = -1;
        while (drivers.hasNext()) {
            DriverInformation driver = new DriverInformation(drivers.next().getValue());
            if (!driver.status.equals("AVAILABLE")) {
                continue;
            }
            double client_driver_distance = this.getClientDriverDistance(
                    new DriverLocation(this.driverLocations.get(String.valueOf(driver.driverId))), client);
            double distance_score = 1 - (client_driver_distance) / MAX_DIST;
            double gender_score = 0;
            if (client.gender_preference.equals("N"))
                gender_score = 1;
            else if (client.gender_preference.equals(driver.gender))
                gender_score = 1;
            double rating_score = driver.rating / 5.0;
            double salary_score = 1 - driver.salary / 100.0;
            double match_score = distance_score * 0.4 + gender_score * 0.2 + rating_score * 0.2 + salary_score * 0.2;
            if (match_score > highest) {
                driverIdWithHighestScore = driver.driverId;
            }
        }
        return driverIdWithHighestScore;
    }

    private void processDriverLocationEvent(Map<String, Object> map) {
        DriverLocation value = new DriverLocation(map);
        this.driverLocations.put(String.valueOf(value.driverId), value.toMap());
    }

    @Override
    public void window(MessageCollector collector, TaskCoordinator coordinator) {
        // this function is called at regular intervals, not required for this
        // project
    }
}
