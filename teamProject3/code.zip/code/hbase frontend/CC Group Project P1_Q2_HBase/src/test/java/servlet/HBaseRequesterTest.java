package servlet;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

/**
 * @author wyen Wei-Yu Yen.
 */
public class HBaseRequesterTest {

    @Test
    public void testGetResponse() throws ClassNotFoundException, SQLException, IOException {

//        HBaseRequester requester = new HBaseRequester();
//        long startTime = System.currentTimeMillis();
//        System.out.println(requester.getResponse("1154999041", "LadiesofLondon"));
//        System.out.println("DB Query Time: " + (System.currentTimeMillis() - startTime));
    }

}
